# movierobbing
抢票电影小程序
<br>
##说明
>此项目ui自己设计。

<img src="http://web.zayata.com/lockes/images/20180328134629.png?page=2017" >
<img src="http://web.zayata.com/lockes/images/20180328134637.png?page=2017" >
<img src="http://web.zayata.com/lockes/images/20180329093416.jpg?page=2017" >
<img src="http://web.zayata.com/lockes/images/20180329093428.jpg?page=2017" >
