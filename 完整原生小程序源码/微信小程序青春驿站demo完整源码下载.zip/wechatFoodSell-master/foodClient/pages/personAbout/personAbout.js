Page({
  data: {
    addressStr: '',
    addressArray: [],
    inputField: false,
    addressInp: ''
  }
  
  })