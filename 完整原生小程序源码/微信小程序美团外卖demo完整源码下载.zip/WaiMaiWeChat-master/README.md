![image](https://github.com/51cc/WaiMaiWeChat/raw/master/1.png)
![image](https://github.com/51cc/WaiMaiWeChat/raw/master/2.png)



微信小程序
实现了常规的外卖点餐、下单的整个UI过程。
想要整套的程序可以咨询QQ532890902
